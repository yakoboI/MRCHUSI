=== Digital Storefront Pro Tools ===
Contributors: yakobochusi
Tags: woocommerce, ai, sms, tanzania, digital products
Requires at least: 5.8
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later

== Description ==
Extends the Digital Storefront theme with AI site builder, WooCommerce digital product features, Tanzanian SMS, and theme controls.

== Features ==
* AI-powered site builder wizard
* WooCommerce digital product previews, demo/trial, expiry, logs
* Tanzanian SMS notifications (M-Pesa, TigoPesa, Airtel, CRDB)
* Theme feature toggles (badges, dark mode, wizard)
* Admin settings page

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/digital-storefront-tools` directory, or install via the WordPress plugin screen.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Make sure the Digital Storefront theme is active.
4. Configure settings under Settings > DSF Tools.
