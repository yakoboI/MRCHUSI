<?php
// Uninstall cleanup for Digital Storefront Pro Tools
if (!defined('WP_UNINSTALL_PLUGIN')) exit;

// Delete plugin options
$options = [
    'dsf_tools_ai_api_key',
    'dsf_tools_sms_api_url',
    'dsf_tools_sms_api_key',
    'dsf_tools_enable_ai_builder',
    'dsf_tools_enable_payment_badges',
    'dsf_tools_enable_dark_mode',
];
foreach ($options as $opt) {
    delete_option($opt);
}

// Delete post meta for previews, demo, expiry, logs
global $wpdb;
$meta_keys = [
    '_dsf_tools_preview_url',
    '_dsf_tools_demo_url',
    '_dsf_tools_download_expiry',
    '_dsf_tools_download_logs',
];
foreach ($meta_keys as $key) {
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s", $key));
}
