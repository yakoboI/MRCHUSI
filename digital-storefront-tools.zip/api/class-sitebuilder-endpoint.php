<?php
/**
 * AI Site Builder REST API endpoint (polished)
 *
 * @package Digital_Storefront_Pro_Tools
 */

defined('ABSPATH') || exit;

/**
 * Registers the AI Site Builder REST API endpoint.
 */
class DSF_Tools_Sitebuilder_Endpoint {
    /**
     * Register the endpoint with WordPress.
     */
    public static function register() {
        register_rest_route('dsf-tools/v1', '/ai-site-builder', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'handle'],
            'permission_callback' => '__return_true',
        ]);
    }

    /**
     * Handle the AI Site Builder request.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public static function handle($request) {
        $params = $request->get_json_params();
        $business = sanitize_text_field($params['business'] ?? '');
        $audience = sanitize_text_field($params['audience'] ?? '');
        $keywords = sanitize_text_field($params['keywords'] ?? '');
        $language = sanitize_text_field($params['language'] ?? '');

        $ai_provider = get_option('dsf_tools_ai_provider', 'openai');
        $prompt = sprintf(
            /* translators: 1: business, 2: audience, 3: keywords, 4: language */
            esc_html__("Create a homepage for a %1$s targeting %2$s. Use these keywords: %3$s. Language: %4$s.", 'digital-storefront-tools'),
            $business,
            $audience,
            $keywords,
            $language
        );
        $result = '';
        $error = '';

        if ($ai_provider === 'openai') {
            $api_key = get_option('dsf_tools_ai_api_key_openai');
            if (!$api_key) $error = esc_html__('OpenAI API key missing.', 'digital-storefront-tools');
            else {
                $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $api_key,
                        'Content-Type' => 'application/json',
                    ],
                    'body' => json_encode([
                        'model' => 'gpt-3.5-turbo',
                        'messages' => [
                            ['role' => 'system', 'content' => 'You are a helpful assistant for digital storefronts.'],
                            ['role' => 'user', 'content' => $prompt],
                        ],
                        'max_tokens' => 400,
                    ]),
                    'timeout' => 30,
                ]);
                if (is_wp_error($response)) $error = $response->get_error_message();
                else {
                    $body = json_decode(wp_remote_retrieve_body($response), true);
                    $result = isset($body['choices'][0]['message']['content']) ? esc_html($body['choices'][0]['message']['content']) : '';
                    if (!$result) $error = esc_html__('No response from OpenAI.', 'digital-storefront-tools');
                }
            }
        } elseif ($ai_provider === 'gemini') {
            $api_key = get_option('dsf_tools_ai_api_key_gemini');
            if (!$api_key) $error = esc_html__('Gemini API key missing.', 'digital-storefront-tools');
            else {
                $response = wp_remote_post('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' . $api_key, [
                    'headers' => [
                        'Content-Type' => 'application/json',
                    ],
                    'body' => json_encode([
                        'contents' => [
                            ['parts' => [ ['text' => $prompt] ] ]
                        ]
                    ]),
                    'timeout' => 30,
                ]);
                if (is_wp_error($response)) $error = $response->get_error_message();
                else {
                    $body = json_decode(wp_remote_retrieve_body($response), true);
                    $result = isset($body['candidates'][0]['content']['parts'][0]['text']) ? esc_html($body['candidates'][0]['content']['parts'][0]['text']) : '';
                    if (!$result) $error = esc_html__('No response from Gemini.', 'digital-storefront-tools');
                }
            }
        } elseif ($ai_provider === 'claude') {
            $api_key = get_option('dsf_tools_ai_api_key_claude');
            if (!$api_key) $error = esc_html__('Claude API key missing.', 'digital-storefront-tools');
            else {
                $response = wp_remote_post('https://api.anthropic.com/v1/messages', [
                    'headers' => [
                        'x-api-key' => $api_key,
                        'anthropic-version' => '2023-06-01',
                        'Content-Type' => 'application/json',
                    ],
                    'body' => json_encode([
                        'model' => 'claude-2.1',
                        'max_tokens' => 400,
                        'messages' => [
                            ['role' => 'user', 'content' => $prompt]
                        ]
                    ]),
                    'timeout' => 30,
                ]);
                if (is_wp_error($response)) $error = $response->get_error_message();
                else {
                    $body = json_decode(wp_remote_retrieve_body($response), true);
                    $result = isset($body['content'][0]['text']) ? esc_html($body['content'][0]['text']) : '';
                    if (!$result) $error = esc_html__('No response from Claude.', 'digital-storefront-tools');
                }
            }
        } else {
            $error = esc_html__('Invalid AI provider.', 'digital-storefront-tools');
        }

        if ($error) {
            return rest_ensure_response(['content' => '<div style="color:red">' . esc_html($error) . '</div>']);
        }
        return rest_ensure_response(['content' => $result]);
    }
}
