<?php
// Registers all plugin REST API endpoints

defined('ABSPATH') || exit;

class DSF_Tools_API_Loader {
    public static function init() {
        add_action('rest_api_init', [__CLASS__, 'register_endpoints']);
    }
    public static function register_endpoints() {
        require_once DSF_TOOLS_PATH . 'api/class-sitebuilder-endpoint.php';
        DSF_Tools_Sitebuilder_Endpoint::register();
    }
}
DSF_Tools_API_Loader::init();
