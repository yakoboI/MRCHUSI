<?php
defined('ABSPATH') || exit;
if (!get_option('dsf_tools_enable_payment_badges')) return;
?>
<div class="dsf-payment-badges">
    <img src="https://via.placeholder.com/80x40?text=M-Pesa" alt="M-Pesa" />
    <img src="https://via.placeholder.com/80x40?text=TigoPesa" alt="TigoPesa" />
    <img src="https://via.placeholder.com/80x40?text=Airtel+Money" alt="Airtel Money" />
    <img src="https://via.placeholder.com/80x40?text=CRDB+Bank" alt="CRDB Bank" />
</div>