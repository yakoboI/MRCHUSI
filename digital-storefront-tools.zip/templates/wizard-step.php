<?php
// Template for AI Site Builder wizard step

defined('ABSPATH') || exit;
?>
<form id="dsf-ai-wizard-step">
    <label>Business Type:<br><input type="text" name="business" required></label><br><br>
    <label>Target Audience:<br><input type="text" name="audience" required></label><br><br>
    <label>Keywords:<br><input type="text" name="keywords"></label><br><br>
    <label>Language:<br><input type="text" name="language" value="English"></label><br><br>
    <button type="submit">Generate</button>
</form>
<div id="dsf-ai-wizard-output"></div>