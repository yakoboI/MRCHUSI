<?php
defined('ABSPATH') || exit;

// Theme control toggles (color, layout)

// Helper to check if a theme feature is enabled
function dsf_tools_theme_feature_enabled($feature) {
    return get_option('dsf_tools_enable_' . $feature, 0);
}

// Example usage: if (dsf_tools_theme_feature_enabled('dark_mode')) { ... }
