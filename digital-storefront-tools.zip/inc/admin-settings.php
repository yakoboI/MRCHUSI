<?php
/**
 * Admin Settings Page for Digital Storefront Pro Tools (polished)
 *
 * @package Digital_Storefront_Pro_Tools
 */

defined('ABSPATH') || exit;

/**
 * Register the plugin settings page in the admin menu.
 */
add_action('admin_menu', function() {
    add_options_page(
        esc_html__('Digital Storefront Tools Settings', 'digital-storefront-tools'),
        esc_html__('DSF Tools', 'digital-storefront-tools'),
        'manage_options',
        'dsf_tools_settings',
        'dsf_tools_render_settings_page'
    );
});

/**
 * Register plugin settings with the Settings API.
 */
add_action('admin_init', function() {
    register_setting('dsf_tools_settings_group', 'dsf_tools_ai_provider');
    register_setting('dsf_tools_settings_group', 'dsf_tools_ai_api_key_openai');
    register_setting('dsf_tools_settings_group', 'dsf_tools_ai_api_key_gemini');
    register_setting('dsf_tools_settings_group', 'dsf_tools_ai_api_key_claude');
    register_setting('dsf_tools_settings_group', 'dsf_tools_sms_api_url');
    register_setting('dsf_tools_settings_group', 'dsf_tools_sms_api_key');
    register_setting('dsf_tools_settings_group', 'dsf_tools_enable_ai_builder');
    register_setting('dsf_tools_settings_group', 'dsf_tools_enable_payment_badges');
    register_setting('dsf_tools_settings_group', 'dsf_tools_enable_dark_mode');
});

/**
 * Render the plugin settings page.
 */
function dsf_tools_render_settings_page() {
    $ai_provider = esc_attr(get_option('dsf_tools_ai_provider', 'openai'));
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Digital Storefront Tools Settings', 'digital-storefront-tools'); ?></h1>
        <form method="post" action="options.php">
            <?php settings_fields('dsf_tools_settings_group'); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="dsf_tools_ai_provider"><?php esc_html_e('AI Provider', 'digital-storefront-tools'); ?></label></th>
                    <td>
                        <select name="dsf_tools_ai_provider" id="dsf_tools_ai_provider">
                            <option value="openai" <?php selected($ai_provider, 'openai'); ?>><?php esc_html_e('OpenAI (GPT-3.5/4)', 'digital-storefront-tools'); ?></option>
                            <option value="gemini" <?php selected($ai_provider, 'gemini'); ?>><?php esc_html_e('Google Gemini', 'digital-storefront-tools'); ?></option>
                            <option value="claude" <?php selected($ai_provider, 'claude'); ?>><?php esc_html_e('Anthropic Claude', 'digital-storefront-tools'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr class="ai-key-row ai-key-openai">
                    <th scope="row"><label for="dsf_tools_ai_api_key_openai"><?php esc_html_e('OpenAI API Key', 'digital-storefront-tools'); ?></label></th>
                    <td><input type="text" id="dsf_tools_ai_api_key_openai" name="dsf_tools_ai_api_key_openai" value="<?php echo esc_attr(get_option('dsf_tools_ai_api_key_openai')); ?>" class="regular-text" autocomplete="off" /></td>
                </tr>
                <tr class="ai-key-row ai-key-gemini">
                    <th scope="row"><label for="dsf_tools_ai_api_key_gemini"><?php esc_html_e('Gemini API Key', 'digital-storefront-tools'); ?></label></th>
                    <td><input type="text" id="dsf_tools_ai_api_key_gemini" name="dsf_tools_ai_api_key_gemini" value="<?php echo esc_attr(get_option('dsf_tools_ai_api_key_gemini')); ?>" class="regular-text" autocomplete="off" /></td>
                </tr>
                <tr class="ai-key-row ai-key-claude">
                    <th scope="row"><label for="dsf_tools_ai_api_key_claude"><?php esc_html_e('Claude API Key', 'digital-storefront-tools'); ?></label></th>
                    <td><input type="text" id="dsf_tools_ai_api_key_claude" name="dsf_tools_ai_api_key_claude" value="<?php echo esc_attr(get_option('dsf_tools_ai_api_key_claude')); ?>" class="regular-text" autocomplete="off" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="dsf_tools_sms_api_url"><?php esc_html_e('SMS API URL', 'digital-storefront-tools'); ?></label></th>
                    <td><input type="text" id="dsf_tools_sms_api_url" name="dsf_tools_sms_api_url" value="<?php echo esc_attr(get_option('dsf_tools_sms_api_url')); ?>" class="regular-text" autocomplete="off" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="dsf_tools_sms_api_key"><?php esc_html_e('SMS API Key', 'digital-storefront-tools'); ?></label></th>
                    <td><input type="text" id="dsf_tools_sms_api_key" name="dsf_tools_sms_api_key" value="<?php echo esc_attr(get_option('dsf_tools_sms_api_key')); ?>" class="regular-text" autocomplete="off" /></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Enable AI Site Builder', 'digital-storefront-tools'); ?></th>
                    <td><input type="checkbox" name="dsf_tools_enable_ai_builder" value="1" <?php checked(get_option('dsf_tools_enable_ai_builder'), 1); ?> /></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Enable Payment Badges', 'digital-storefront-tools'); ?></th>
                    <td><input type="checkbox" name="dsf_tools_enable_payment_badges" value="1" <?php checked(get_option('dsf_tools_enable_payment_badges'), 1); ?> /></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Enable Dark Mode', 'digital-storefront-tools'); ?></th>
                    <td><input type="checkbox" name="dsf_tools_enable_dark_mode" value="1" <?php checked(get_option('dsf_tools_enable_dark_mode'), 1); ?> /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <script>
    jQuery(function($){
        function showAIKeyRow() {
            var provider = $('#dsf_tools_ai_provider').val();
            $('.ai-key-row').hide();
            $('.ai-key-' + provider).show();
        }
        $('#dsf_tools_ai_provider').on('change', showAIKeyRow);
        showAIKeyRow();
    });
    </script>
    <?php
}
