<?php
// AI-powered site builder logic

defined('ABSPATH') || exit;

// Shortcode for AI Site Builder wizard
add_shortcode('dsf_ai_site_builder', function() {
    if (!get_option('dsf_tools_enable_ai_builder')) return '';
    ob_start();
    include DSF_TOOLS_PATH . 'templates/wizard-step.php';
    ?>
    <script>
    jQuery(function($){
        $('#dsf-ai-wizard-step').on('submit', function(e){
            e.preventDefault();
            var data = $(this).serializeArray().reduce(function(obj, item) {
                obj[item.name] = item.value;
                return obj;
            }, {});
            $('#dsf-ai-wizard-output').html('Generating...');
            $.ajax({
                url: '/wp-json/dsf-tools/v1/ai-site-builder',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(data),
                success: function(res) {
                    $('#dsf-ai-wizard-output').html(res.content);
                },
                error: function() {
                    $('#dsf-ai-wizard-output').html('Failed to generate.');
                }
            });
        });
    });
    </script>
    <?php
    return ob_get_clean();
});
