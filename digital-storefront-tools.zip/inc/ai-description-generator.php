<?php
/**
 * AI Product Description Generator (with real AI API integration)
 *
 * @package Digital_Storefront_Pro_Tools
 */

defined('ABSPATH') || exit;

/**
 * Add AI Description Generator meta box to product edit screen.
 */
add_action('add_meta_boxes', function () {
    add_meta_box(
        'dsf_tools_ai_generator',
        esc_html__('🧠 AI Description Generator', 'digital-storefront-tools'),
        'dsf_tools_render_ai_generator_box',
        'product',
        'side'
    );
});

/**
 * Render the AI Description Generator meta box.
 *
 * @param WP_Post $post
 */
function dsf_tools_render_ai_generator_box($post) {
    $nonce = wp_create_nonce('dsf_tools_generate_description_' . $post->ID);
    ?>
    <button type="button" class="button" id="dsf-generate-description" data-product-id="<?php echo esc_attr($post->ID); ?>" data-nonce="<?php echo esc_attr($nonce); ?>">
        <?php esc_html_e('🔮 Generate Description', 'digital-storefront-tools'); ?>
    </button>
    <div id="dsf-description-output" style="margin-top:10px;"></div>
    <script>
    document.getElementById('dsf-generate-description').addEventListener('click', async function() {
        const btn = this;
        const output = document.getElementById('dsf-description-output');
        output.innerHTML = '🕐 <?php echo esc_js(__('Working...', 'digital-storefront-tools')); ?>';
        const res = await fetch(ajaxurl, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=dsf_generate_description&product_id=' + encodeURIComponent(btn.dataset.productId) + '&nonce=' + encodeURIComponent(btn.dataset.nonce)
        });
        const data = await res.json();
        output.innerHTML = data.success && data.data.description ? '<strong>✅ <?php echo esc_js(__('Description:', 'digital-storefront-tools')); ?></strong><br>' + data.data.description : '❌ <?php echo esc_js(__('Failed:', 'digital-storefront-tools')); ?> ' + (data.data && data.data.error ? data.data.error : '<?php echo esc_js(__('Unknown error.', 'digital-storefront-tools')); ?>');
    });
    </script>
    <?php
}

/**
 * AJAX callback to generate AI description.
 */
add_action('wp_ajax_dsf_generate_description', function () {
    $id = intval($_POST['product_id'] ?? 0);
    $nonce = $_POST['nonce'] ?? '';
    if (!$id || !wp_verify_nonce($nonce, 'dsf_tools_generate_description_' . $id)) {
        wp_send_json_error(['error' => esc_html__('Invalid request or nonce.', 'digital-storefront-tools')]);
    }

    $post = get_post($id);
    $title = $post ? $post->post_title : esc_html__('Product', 'digital-storefront-tools');
    $category = $post ? get_the_terms($id, 'product_cat') : [];
    $cat_name = $category && !is_wp_error($category) && isset($category[0]) ? $category[0]->name : '';

    $ai_provider = get_option('dsf_tools_ai_provider', 'openai');
    $prompt = sprintf(
        /* translators: 1: product title, 2: category name */
        esc_html__("Write a compelling product description for a digital product titled '%1$s' in the category '%2$s'.", 'digital-storefront-tools'),
        $title,
        $cat_name
    );
    $result = '';
    $error = '';

    if ($ai_provider === 'openai') {
        $api_key = get_option('dsf_tools_ai_api_key_openai');
        if (!$api_key) $error = esc_html__('OpenAI API key missing.', 'digital-storefront-tools');
        else {
            $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type' => 'application/json',
                ],
                'body' => json_encode([
                    'model' => 'gpt-3.5-turbo',
                    'messages' => [
                        ['role' => 'system', 'content' => 'You are a helpful assistant for digital storefronts.'],
                        ['role' => 'user', 'content' => $prompt],
                    ],
                    'max_tokens' => 200,
                ]),
                'timeout' => 30,
            ]);
            if (is_wp_error($response)) $error = $response->get_error_message();
            else {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                $result = isset($body['choices'][0]['message']['content']) ? esc_html($body['choices'][0]['message']['content']) : '';
                if (!$result) $error = esc_html__('No response from OpenAI.', 'digital-storefront-tools');
            }
        }
    } elseif ($ai_provider === 'gemini') {
        $api_key = get_option('dsf_tools_ai_api_key_gemini');
        if (!$api_key) $error = esc_html__('Gemini API key missing.', 'digital-storefront-tools');
        else {
            $response = wp_remote_post('https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' . $api_key, [
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
                'body' => json_encode([
                    'contents' => [
                        ['parts' => [ ['text' => $prompt] ] ]
                    ]
                ]),
                'timeout' => 30,
            ]);
            if (is_wp_error($response)) $error = $response->get_error_message();
            else {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                $result = isset($body['candidates'][0]['content']['parts'][0]['text']) ? esc_html($body['candidates'][0]['content']['parts'][0]['text']) : '';
                if (!$result) $error = esc_html__('No response from Gemini.', 'digital-storefront-tools');
            }
        }
    } elseif ($ai_provider === 'claude') {
        $api_key = get_option('dsf_tools_ai_api_key_claude');
        if (!$api_key) $error = esc_html__('Claude API key missing.', 'digital-storefront-tools');
        else {
            $response = wp_remote_post('https://api.anthropic.com/v1/messages', [
                'headers' => [
                    'x-api-key' => $api_key,
                    'anthropic-version' => '2023-06-01',
                    'Content-Type' => 'application/json',
                ],
                'body' => json_encode([
                    'model' => 'claude-2.1',
                    'max_tokens' => 200,
                    'messages' => [
                        ['role' => 'user', 'content' => $prompt]
                    ]
                ]),
                'timeout' => 30,
            ]);
            if (is_wp_error($response)) $error = $response->get_error_message();
            else {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                $result = isset($body['content'][0]['text']) ? esc_html($body['content'][0]['text']) : '';
                if (!$result) $error = esc_html__('No response from Claude.', 'digital-storefront-tools');
            }
        }
    } else {
        $error = esc_html__('Invalid AI provider.', 'digital-storefront-tools');
    }

    if ($error) {
        wp_send_json_error(['error' => $error]);
    }
    wp_send_json_success(['description' => $result]);
});
