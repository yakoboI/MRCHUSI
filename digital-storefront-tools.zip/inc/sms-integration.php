<?php
// Tanzanian SMS API integration

defined('ABSPATH') || exit;

add_action('woocommerce_order_status_completed', function($order_id) {
    $order = wc_get_order($order_id);
    if (!$order) return;
    $phone = $order->get_billing_phone();
    $name = $order->get_billing_first_name();
    $api_url = get_option('dsf_tools_sms_api_url');
    $api_key = get_option('dsf_tools_sms_api_key');
    if (!$api_url || !$api_key || !$phone) return;
    $message = sprintf(__('Hello %s, your order #%d is complete. Thank you!', 'digital-storefront-tools'), $name, $order->get_id());
    $body = [
        'to' => $phone,
        'message' => $message,
        'api_key' => $api_key
    ];
    wp_remote_post($api_url, [
        'body' => $body,
        'timeout' => 10,
    ]);
});
