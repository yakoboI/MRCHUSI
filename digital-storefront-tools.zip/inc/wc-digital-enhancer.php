<?php
// WooCommerce digital product extensions

defined('ABSPATH') || exit;

// Add file preview before purchase (PDF, audio, video)
add_action('woocommerce_before_add_to_cart_form', function() {
    global $product;
    if ($product && $product->is_downloadable()) {
        $preview_url = get_post_meta($product->get_id(), '_dsf_tools_preview_url', true);
        if ($preview_url) {
            $type = pathinfo($preview_url, PATHINFO_EXTENSION);
            echo '<div class="dsf-tools-preview">';
            if (in_array($type, ['pdf'])) {
                echo '<embed src="' . esc_url($preview_url) . '" type="application/pdf" width="100%" height="400px">';
            } elseif (in_array($type, ['mp3', 'wav'])) {
                echo '<audio controls src="' . esc_url($preview_url) . '"></audio>';
            } elseif (in_array($type, ['mp4', 'webm'])) {
                echo '<video controls width="100%" height="240" src="' . esc_url($preview_url) . '"></video>';
            }
            echo '</div>';
        }
    }
});

// Add Free Trial/Demo button via shortcode
add_shortcode('dsf_tools_demo_button', function($atts) {
    $atts = shortcode_atts(['product_id' => 0, 'label' => __('Free Trial', 'digital-storefront-tools')], $atts);
    $url = get_post_meta($atts['product_id'], '_dsf_tools_demo_url', true);
    if ($url) {
        return '<a class="button dsf-tools-demo-btn" href="' . esc_url($url) . '" target="_blank">' . esc_html($atts['label']) . '</a>';
    }
    return '';
});

// Download expiry and logs
add_filter('woocommerce_file_download_method', function($method, $product_id, $download_id) {
    $expiry = get_post_meta($product_id, '_dsf_tools_download_expiry', true);
    if ($expiry && strtotime($expiry) < time()) {
        return 'redirect'; // disables download
    }
    return $method;
}, 10, 3);

add_action('woocommerce_download_product', function($download_id, $product_id, $user_email) {
    $logs = get_post_meta($product_id, '_dsf_tools_download_logs', true);
    if (!is_array($logs)) $logs = [];
    $logs[] = [
        'user' => $user_email,
        'time' => current_time('mysql'),
        'download_id' => $download_id
    ];
    update_post_meta($product_id, '_dsf_tools_download_logs', $logs);
}, 10, 3);

// Admin options for enabling/disabling features (uses options from admin-settings.php)
function dsf_tools_wc_feature_enabled($option) {
    return get_option($option, 1);
}
