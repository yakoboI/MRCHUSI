// Admin UI JS

// JS for DSF Tools admin settings
jQuery(document).ready(function($){
    if ($('.settings_page_dsf_tools_settings .updated').length) {
        alert('Settings saved!');
    }
});