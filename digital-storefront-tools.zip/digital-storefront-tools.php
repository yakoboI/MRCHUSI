<?php
/*
Plugin Name: Digital Storefront Pro Tools
Plugin URI: https://yakobochusi.site/
Description: Extends the Digital Storefront theme with AI site builder, WooCommerce enhancements, Tanzanian SMS, and theme controls.
Version: 1.0.0
Author: Yakobo Abeld Chusi
Author URI: https://yakobochusi.site/
License: GPL2
*/

defined('ABSPATH') || exit;

// Define plugin constants
if (!defined('DSF_TOOLS_PATH')) {
    define('DSF_TOOLS_PATH', plugin_dir_path(__FILE__));
}
if (!defined('DSF_TOOLS_URL')) {
    define('DSF_TOOLS_URL', plugin_dir_url(__FILE__));
}
if (!defined('DSF_TOOLS_BASENAME')) {
    define('DSF_TOOLS_BASENAME', plugin_basename(__FILE__));
}

// Activation/Deactivation hooks
register_activation_hook(__FILE__, function() {
    // Place activation logic here (e.g., default options)
});
register_deactivation_hook(__FILE__, function() {
    // Place deactivation logic here (e.g., cleanup)
});

// Load plugin textdomain
function dsf_tools_load_textdomain() {
    load_plugin_textdomain('digital-storefront-tools', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'dsf_tools_load_textdomain');

// Only run plugin logic if the correct theme is active
add_action('after_setup_theme', function () {
    $theme = wp_get_theme();
    if ($theme->get('TextDomain') !== 'digital-storefront-theme') {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>Digital Storefront Pro Tools</strong> requires the <strong>Digital Storefront</strong> theme to be active.</p></div>';
        });
        return;
    }
    // Load core includes
    foreach (glob(DSF_TOOLS_PATH . 'inc/*.php') as $file) {
        require_once $file;
    }
});

// Add settings link on plugins page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links) {
    $settings_link = '<a href="' . admin_url('options-general.php?page=dsf_tools_settings') . '">' . __('Settings', 'digital-storefront-tools') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
});
